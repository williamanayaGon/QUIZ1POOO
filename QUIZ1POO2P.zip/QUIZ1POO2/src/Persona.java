public class Persona {
    String documento;
    String nombres;
    String apellidos;
    int edad;
}
