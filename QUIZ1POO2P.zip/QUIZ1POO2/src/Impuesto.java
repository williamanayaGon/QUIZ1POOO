public class Impuesto {
    String id_impuesto;
    String nombre;
    String estado;
}
