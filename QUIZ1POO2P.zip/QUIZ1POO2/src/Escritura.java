import java.util.Date;

public class Escritura {
    String numero;
    Date fecha;
    int notaria;
}
