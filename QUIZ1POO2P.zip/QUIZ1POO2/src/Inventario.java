import java.util.Date;

public class Inventario {
    String id_inventario;
    Date fecha;
}
