public class Propietario {
    String id_Propietario;


    public String getId_Propietario() {
        return id_Propietario;
    }

    public void setId_Propietario(String id_Propietario) {
        this.id_Propietario = id_Propietario;
    }
}
