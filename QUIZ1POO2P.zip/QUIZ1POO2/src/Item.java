public class Item {
    String id_Item;
    String estado;
    String descripcion;
}
