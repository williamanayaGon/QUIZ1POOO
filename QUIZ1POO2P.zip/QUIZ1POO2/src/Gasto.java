import java.util.Date;

public class Gasto {
    String id_gasto;
    Date fecha;
    float valor;
    String descripcion;
}
