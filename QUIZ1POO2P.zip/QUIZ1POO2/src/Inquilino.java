public class Inquilino {
    String id_Inquilino;
    String numeroContrato;
    String telefono;
    String correo;
}
