public class Mantenimiento {
    String id_mantenimiento;
    Persona responsable;
}
