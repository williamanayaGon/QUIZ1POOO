import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class GestionPropietariosGUI extends JFrame {
    private ArrayList<Propietario> propietarios = new ArrayList<>();

    private JButton btnRegistrar;
    private JButton btnListar;
    private JButton btnBuscar;

    public GestionPropietariosGUI() {
        setTitle("Gestión de Propietarios");
        setSize(300, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        btnRegistrar = new JButton("Registrar");
        btnListar = new JButton("Listar");
        btnBuscar = new JButton("Buscar");

        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cierra la ventana actual
                new RegistroPropietarioGUI(); // Abre una nueva ventana para registrar propietarios
            }
        });

        btnListar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cierra la ventana actual
                new ListarPropietariosGUI(); // Abre una nueva ventana para listar propietarios
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cierra la ventana actual
                new BuscarPropietarioGUI(); // Abre una nueva ventana para buscar propietarios
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 3));
        panel.add(btnRegistrar);
        panel.add(btnListar);
        panel.add(btnBuscar);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GestionPropietariosGUI();
            }
        });
    }
}

class RegistroPropietarioGUI extends JFrame {
    private JTextField txtIdPropietario;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    private JTextField txtEdad;
    private JButton btnRegistrar;

    public RegistroPropietarioGUI() {
        setTitle("Registro de Propietario");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        txtIdPropietario = new JTextField(20);
        txtNombres = new JTextField(20);
        txtApellidos = new JTextField(20);
        txtEdad = new JTextField(20);
        btnRegistrar = new JButton("Registrar");

        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registrarPropietario();
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));
        panel.add(new JLabel("ID Propietario:"));
        panel.add(txtIdPropietario);
        panel.add(new JLabel("Nombres:"));
        panel.add(txtNombres);
        panel.add(new JLabel("Apellidos:"));
        panel.add(txtApellidos);
        panel.add(new JLabel("Edad:"));
        panel.add(txtEdad);
        panel.add(btnRegistrar);

        add(panel);
        setVisible(true);
    }

    private void registrarPropietario() {
        String idPropietario = txtIdPropietario.getText();
        String nombres = txtNombres.getText();
        String apellidos = txtApellidos.getText();
        int edad = Integer.parseInt(txtEdad.getText());

        // Aquí puedes hacer lo que necesites con los datos del propietario, por ejemplo, agregarlo a la lista de propietarios
        JOptionPane.showMessageDialog(this, "Propietario registrado:\nID: " + idPropietario + "\nNombres: " + nombres + "\nApellidos: " + apellidos + "\nEdad: " + edad);
        dispose(); // Cierra la ventana actual
        new GestionPropietariosGUI(); // Vuelve a la ventana principal
    }
}

class ListarPropietariosGUI extends JFrame {
    private ArrayList<Propietario> propietarios = new ArrayList<>();

    public ListarPropietariosGUI() {
        setTitle("Listado de Propietarios");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Aquí puedes obtener los propietarios de la lista y mostrarlos en un JTextArea o similar

        JTextArea textArea = new JTextArea(10, 30);
        JScrollPane scrollPane = new JScrollPane(textArea);
        textArea.setEditable(false);

        for (Propietario propietario : propietarios) {
            textArea.append("ID: " + propietario.id_Propietario + "\n"); // Puedes agregar más detalles si lo deseas
        }

        add(scrollPane);
        pack();
        setVisible(true);
    }
}

class BuscarPropietarioGUI extends JFrame {
    private JTextField txtIdPropietario;
    private JButton btnBuscar;

    public BuscarPropietarioGUI() {
        setTitle("Buscar Propietario");
        setSize(300, 100);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        txtIdPropietario = new JTextField(20);
        btnBuscar = new JButton("Buscar");

        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarPropietario();
            }
        });

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 2));
        panel.add(new JLabel("ID Propietario:"));
        panel.add(txtIdPropietario);
        panel.add(btnBuscar);

        add(panel);
        setVisible(true);
    }

    private void buscarPropietario() {
        String idPropietario = txtIdPropietario.getText();

        // Aquí puedes buscar el propietario por su ID y mostrar sus detalles en una nueva ventana o en un JOptionPane

        JOptionPane.showMessageDialog(this, "Propietario encontrado:\nID: " + idPropietario); // Esto es solo un ejemplo, debes implementar la lógica para buscar y mostrar los detalles del propietario
        dispose(); // Cierra la ventana actual
        new GestionPropietariosGUI(); // Vuelve a la ventana principal
    }
}
